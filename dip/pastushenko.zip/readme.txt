new_model.ipynb - Файл модели
	Необходимые для запуска библиотеки:
	pandas
	numpy
	sklearn
	xgboost
	matplotlib
	seaborn
	dateutil
	json
	io
	graphviz
	locale
	
name_parse.ipynb - файл с кодом парсинга сайта kakzovut.ru
	
schools.ipynb - файл с кодом попытки обогащения данных по московским школам данными о ЕГЭ

unload.sql - основной запрос, получающий фичи

names_m.json, names_w.json - файлы со словарями женских и мужских русских имен

charts - папка с кодом и запросами для построения графиков